
###################
# GWAS_functions.R
#####################

cat (
  "
sourcing 'gwas_functions.R'.
  ------------------------------------
  
  Adding functions
  * plot_manhattan_all_chr (GWAS.p, title_lab='', x_lab.cex=1, x_min=0, y_min=0, y_max=15, cex=0.8, threshold1=3, threshold2=5)
  * 
  
  ", file=stderr()
)



###### functions
chr_max <- function(x) {
  
  #   if (!exists(chr_sizes)) {
  #     chr_sizes <- read.table("chr_sizes_ens52.tab");
  #     #names(chr_sizes) <- c('chr', 'start','end')
  #  }
  chr_sizes$end[chr_sizes$chr==x]
}
# function for returning the values of cum chr
cum_chr <- function(GWAS.p,chr) GWAS.p[GWAS.p$CHR==chr,'BP'] + chr_cum[chr_cum$chr==chr,'start']-1
#near
##cum_chr.near <- function(x) GWAS.near.p[GWAS.near.p$CHR==x,3] + chr_cum[chr_cum$start==x,2]-1

get_xlab.pos <- function (x)   {(chr_cum$start[chr_cum$chr==x] + chr_cum$end[chr_cum$chr==x])/2 }

## test colors
# pie(1:4,col=c('#0000FF', '#00FF00', '#ff0000', '#FFFF00'))


###
#
plot_manhattan_all_chr <- function (GWAS.p, title_lab='', x_lab.cex=0.5, x_min=0, y_min=0, y_max=15, cex=0.8, threshold1=3, threshold2=5){
  #test: GWAS.p=assoc.test.p
  #test: title_lab='test'
  if (test & verbose) {
    print(str(GWAS.p))
  }
  for(chr in chr_cum$chr) {GWAS.p[GWAS.p$CHR==chr,"BP"] <- cum_chr(GWAS.p,chr) }
  
  ## the chr are factors so I need to convert first to numeric, and then to logical to use as a filter
  odd_chr<-as.logical(as.numeric(GWAS.p$CHR)%%2)
  ## odd_chr_near <- as.logical(as.numeric(GWAS.near.p$CHR)%%2)
  x_max <- chr_cum$end[chr_cum$chr==24] #max(GWAS.p$end)
  log_p_max <- -log10(min(GWAS.p$P, na.rm=T)) 
  y_max <- max(c(ceiling(log_p_max), y_max))
   
  plot(1, type="n"
       , ylab="-log10(P-value)"
       , xlab="Location"
       , xlim=c(x_min,x_max)
       , ylim=c(y_min,y_max)
       , xaxt="n"
       , yaxt="n"
       , pch=20
       #, las=1
       , cex=1
       , cex.lab=1.2
       , cex.axis=1.1
       , main=paste("Manhattan plot for all Chromosomes\n", title_lab)
  )
  
  axis(2, at=y_min:y_max, lab=as.character(y_min:y_max), las=1)
  
  ##  points(-log10(GWAS.near.p$P[odd_chr_near]) ~ GWAS.near.p$BP[odd_chr_near]
  ##         , col="grey"
  ##         , xlim=c(0,x_max)
  ##         , ylim=c(3,15)
  ##         , xaxt="n"
  ##         , pch=20
  ##         , cex=1
  ##         )
  ##
  ##
  ##  points(-log10(GWAS.near.p$P[!odd_chr_near]) ~ GWAS.near.p$BP[!odd_chr_near]
  ##         , col="pink"
  ##         , xlim=c(0,x_max)
  ##         , ylim=c(3,15)
  ##         , xaxt="n"
  ##         , pch=20
  ##         , cex=1
  ##         )
  ##
  ##  
  
  
  
  points(  GWAS.p$logP[odd_chr] ~ GWAS.p$BP[odd_chr]
           , col="pink"
           , xlim=c(x_min,x_max)
           , ylim=c(y_min, y_max)
           , xaxt="n"
           , pch=20
           , cex=cex
  )
  
  points( GWAS.p$logP[!odd_chr] ~ GWAS.p$BP[!odd_chr]
         , col="grey50"
         , xlim=c(x_min,x_max)
         , ylim=c(y_min,y_max)
         , xaxt="n"
         , pch=20
         , cex=cex
  )
  ## add color to almost significant ones
  points(GWAS.p$logP[!odd_chr & GWAS.p$logP > threshold1 & GWAS.p$logP < threshold2] ~ GWAS.p$BP[!odd_chr & GWAS.p$logP > threshold1 & GWAS.p$logP < threshold2]
         , col="orange"
         , xlim=c(x_min,x_max)
         , ylim=c(y_min,y_max)
         , xaxt="n"
         , pch=20
         , cex=cex*1.2
  )
  
  points(GWAS.p$logP[odd_chr & GWAS.p$logP>threshold1  & GWAS.p$logP < threshold2] ~ GWAS.p$BP[odd_chr & GWAS.p$logP>threshold1 & GWAS.p$logP < threshold2]
         , col="blue"
         , xlim=c(x_max,x_max)
         , ylim=c(y_min,y_max)
         , xaxt="n"
         , pch=20
         , cex=cex*1.2
  )
  
  ## add color to significant ones
  ## <TO_DO> if -log10 > 15 encircle the dot in a circle
  ## get the points bigger than 15
  points( GWAS.p$logP[!odd_chr & GWAS.p$logP > threshold2] ~ GWAS.p$BP[!odd_chr & GWAS.p$logP > threshold2]
         , col="red"
         , xlim=c(x_max,x_max)
         , ylim=c(y_min,y_max)
         , xaxt="n"
         , pch=20
         , cex=cex*1.2
  )
  
  points(GWAS.p$logP[odd_chr & GWAS.p$logP > threshold2] ~ GWAS.p$BP[odd_chr & GWAS.p$logP > threshold2]
         , col="black"
         , xlim=c(x_max,x_max)
         , ylim=c(y_min,y_max)
         , xaxt="n"
         , pch=20
         , cex=cex*1.2
  )
  
  ## claculate chr position in the midle of each chr
  chr_list <- chr_cum$chr
  chr_labels <- chr_cum$chr_label

  x_lab.pos <- rbind(chr_list,sapply(chr_list, get_xlab.pos))
  mtext(chr_labels, side=1, at=sapply(chr_list, get_xlab.pos), cex=x_lab.cex)
  
  ## plot treshold lines
  abline(h=threshold1)
  abline(h=threshold2)
}
