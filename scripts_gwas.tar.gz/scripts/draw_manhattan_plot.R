#!/usr/bin/env Rscript

##################
# Manhattan  Plot
##################
rm(list=ls())

#base_dir <- Sys.getenv('MANHATTAN_PLOT_BASE_DIR')# [%MANHATTAN_PLOT_BASE_DIR%]
base_dir <- '[%MANHATTAN_PLOT_BASE_DIR%]'
if(!exists("base_dir") | base_dir=="")stop(paste('#[ERROR] The environmental variable MANHATTAN_PLOT_BASE_DIR has not been set.'))

assoc_file <- '[%ASSOC_FILE%]'
title_lab  <- '[%TITLE_PLOT%]'
user       <- '[%USER%]'
job_name   <- '[%JOB_NAME%]'
output     <- '[%OUT_FORMAT%]' # pdf, png, stdout

base_dir
assoc_file
title_lab
user
job_name
output


if (output != "stdout") {
	# this is here just in case we want to change the name
	file_out = paste('manhattan_plot-',user,'-', job_name, ".", output, sep="") #"manhattan_plot-pmg-chisqr_ldl.pdf"
}



library(ggplot2)

# 

test=1
verbose =1

data_dir <- file.path(base_dir,"data")

chr_size_file <- "chr_sizes_ens75.tab"
chr_cum_size_file <- "chr_cum_sizes_ens75.tab"


chr_sizes <- read.delim(file.path(data_dir,chr_size_file), header=F)
names(chr_sizes) <- c("chr", "start","end")
chr_sizes$chr<- 1:24
chr_sizes$chr_label<- c(1:22,"X", "Y")

str(chr_sizes)


chr_cum_size <- read.delim(file.path(data_dir,chr_cum_size_file), header=F)
names(chr_cum_size) <- c("chr", "start","end")
chr_cum_size$chr<- 1:24
chr_cum_size$chr_label<- c(1:22,"X", "Y")

chr_cum <- chr_cum_size
str(chr_cum)


ggplot(chr_sizes, aes(chr, end))+ geom_bar(stat="identity")

#assoc_file <- file.path(base_dir,"test/data", 'test.assoc.tsv')
assoc.test.p <- read.table(assoc_file, header=TRUE)
head(assoc.test.p)
str(assoc.test.p)


if (output == "stdout") {
	print("output to STDOUT")
} else {
	print("output and file_out str:")
	str(output)
	str(file_out)

	##if(output=="stdout"){print("printing to standard 	output")}else{ pdf(file_out.pdf, width=7, height=6)}
	if(output=="pdf") {
	  pdf(file_out, width=7, height=7)
	} else {
	  if(output=="png") {
	    png(file_out, width=800, height=400)
	  } else {
	    stop("Sorry but wrong output format. Only 'pdf' or 	'png' allowed")
	  }
	}
}

plot_manhattan_all_chr(assoc.test.p
                       , title_lab=title_lab
                       , x_lab.cex=0.6
                       , x_min=0
                       , y_min=0
                       , y_max=15
                       , cex=0.8
                       , threshold1=3
                       , threshold2=5
                       )


if(output != "stdout"){dev.off()}
