#!/usr/bin/env Rscript

##################
# Manhattan  Plot
##################
rm(list=ls())

#base_dir <- '[%BASE_DIR%]'
# Sys.setenv(GWAS_BASE_DIR='/DATA/workspace/master_bioinfo-2016/gwas_class')
base_dir <- Sys.getenv('GWAS_BASE_DIR')# [%MANHATTAN_PLOT_BASE_DIR%]
base_dir
scripts_dir <- file.path(base_dir,'data','scripts')
scripts_dir
data_dir <- file.path(base_dir,'data', 'purcell_example', 'test1')
data_dir
out_dir <- data_dir
out_dir
modules_dir <- file.path(scripts_dir,"modules")
modules_dir

if(!exists("base_dir") | base_dir=="")stop(paste('#[ERROR] The environmental variable MANHATTAN_PLOT_BASE_DIR has not been set.'))

#title_lab  <- 'Manhatan_wgas3_assoc'
#assoc_file_name <- 'wgas3_assoc_adjust.assoc.sorted.tab'

title_lab  <- 'Manhatan_wgas3_assoc_subpob'
assoc_file_name <- Sys.getenv('GWAS_ASSOC_FILE_NAME') #'cmh1.cmh.sorted.tab'

assoc_file <- file.path(data_dir, assoc_file_name)

user       <- 'pmg'
job_name   <- 'job_name'
output     <- 'pdf' # pdf, png, stdout
# 
# assoc_file <- '[%ASSOC_FILE%]'
# title_lab  <- '[%TITLE_PLOT%]'
# user       <- '[%USER%]'
# job_name   <- '[%JOB_NAME%]'
# output     <- '[%OUT_FORMAT%]' # pdf, png, stdout
# output_dir <- '[%OUTPUT_DIR%]'


base_dir
assoc_file
title_lab
user
job_name
output

source(file.path(modules_dir,'gwas_functions.R'))
source(file.path(modules_dir,'pmg_utils.R'))

file_out=''

if (output != "stdout") {
  ## this is here just in case we want to change the name
  manhattan_plot_file_out_path <- file.path(out_dir, paste0(assoc_file_name,'.manhattan')) #'[%MANHATTAN_PLOT_OUT_PATH%]'
}

file_out

#library(ggplot2)

# 

test=1
verbose =1

scripts_data_dir <- file.path(scripts_dir,"data")
scripts_data_dir
chr_size_file <- "chr_sizes_ens75.tab"
chr_cum_size_file <- "chr_cum_sizes_ens75.tab"


chr_sizes <- read.delim(file.path(scripts_data_dir,chr_size_file), header=F)
names(chr_sizes) <- c("chr", "start","end")
chr_sizes$chr<- 1:24
chr_sizes$chr_label<- c(1:22,"X", "Y")

str(chr_sizes)


chr_cum_size <- read.delim(file.path(scripts_data_dir,chr_cum_size_file), header=F)
names(chr_cum_size) <- c("chr", "start","end")
chr_cum_size$chr<- 1:24
chr_cum_size$chr_label<- c(1:22,"X", "Y")

chr_cum <- chr_cum_size
str(chr_cum)


#<TO_DO> use for plotting a quick cariotype with regions with signal
#ggplot(chr_sizes, aes(chr, end))+ geom_bar(stat="identity")

#assoc_file <- file.path(base_dir,"test/data", 'test.assoc.tsv')
assoc.test.p <- read.table(assoc_file, header=TRUE)
head(assoc.test.p)

assoc.test.p$logP <- -log10(assoc.test.p$P)
str(assoc.test.p)

top_hits <- subset(assoc.test.p, logP>=3)
top_hits.count <- nrow(top_hits)
top_hits.table.file_path <- file.path(out_dir, paste0(assoc_file_name,'.top_hits')) #'[%TOP_HITS_DF_OUT_PATH%]'

pmg_feedback(c("# TOP HITS: there are ",top_hits.count," SNPs with -logP value >= 3.\n"))
pmg_feedback(c("# list of top_hits writed to file '",top_hits.table.file_path,"'\n"))
write.table(x=top_hits, file=top_hits.table.file_path, row.names=F, quote=F, sep="\t")




if (output == "stdout") {
	print("output to STDOUT")
} else {
	print("output and file_out str:")
	str(output)
	str(file_out)

	##if(output=="stdout"){print("printing to standard 	output")}else{ pdf(file_out.pdf, width=7, height=6)}
	if(output=="pdf") {
	  pdf(paste0(manhattan_plot_file_out_path, '.pdf'), width=8, height=4)
	} else {
	  if(output=="png") {
	    png(paste0( manhattan_plot_file_out_path, '.png'), width=800, height=400)
	  } else {
	    stop("Sorry but wrong output format. Only 'pdf' or 	'png' allowed")
	  }
	}
}

plot_manhattan_all_chr(assoc.test.p
                       , title_lab=title_lab
                       , x_lab.cex=0.6
                       , x_min=0
                       , y_min=0
                       , y_max=15
                       , cex=0.8
                       , threshold1=3
                       , threshold2=5
                       )


if(output != "stdout"){dev.off()}
