#!/usr/bin/env sh
perl -lane 'print join ("\t",@F)' $1 > $2
echo "$1 --> $2"

